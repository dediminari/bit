﻿[PSCustomObject]@{
    "SHA256" = [PSCustomObject]@{Enable = "0"}
    "SHA256ab" = [PSCustomObject]@{Enable = "0"}
}