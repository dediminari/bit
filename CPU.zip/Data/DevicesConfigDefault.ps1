﻿[PSCustomObject]@{
    "GPU" = [PSCustomObject]@{DefaultOCprofile="Profile2"}
}